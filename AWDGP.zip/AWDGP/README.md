<br>Blueprint->_init_.py: empty file</br>
         <br>->auth.py: route to login/register page, send verification code</br>
         <br>->Form.py: validate form input.</br>
         <br>->Forum.py route to/ functions of forum page</br>
<br>Static: Bootstrap/jQuery/CSS files</br>
<br>templates: html files(Jinja)</br>
<br>venv: Virtual Environment</br>
<br>Instance:SQLite DBfile</br>
<br>Migration:DB migrations</br>
<br>app.py:flask config/ SQLAlchemy config/ cookie session</br>
<br>config.py: verification forwarding config</br>
<br>decor.py: redirect unregisted user to login page</br>
<br>exts.py: prevent reference loop</br>
<br>models.py: DB(ORM)</br>
