# Mail Forwarding (SMTP)


MAIL_SERVER = 'smtp.qq.com'
MAIL_PORT = 465
MAIL_USE_TLS = False
MAIL_USE_SSL = True
MAIL_USERNAME = 'wangweihua1997@qq.com'
MAIL_PASSWORD = 'rocelfnazapubdgb'
MAIL_DEFAULT_SENDER = "wangweihua1997@qq.com"

